export interface Product {
  id: string;
  name: string;
  brand: 'Bitmain' | 'MicroBT' | 'Canaan' | 'Goldshell' | 'Jasminer' | string;
  model: string;
  price: number;
  hashrate: number;
  hashrateUnit: 'TH/s' | 'GH/s' | 'MH/s' | string;
  power: number; // Watts
  algorithm: string;
  coins: string[];
  efficiency: number; // J/T or J/G or J/M
  efficiencyUnit: 'J/T' | 'J/G' | 'J/M' | string;
  status: 'In Stock' | 'Pre-order' | 'Out of Stock' | 'Hot';
  releaseDate: string;
  noise: number; // dB
  description: string;
  coolingType: 'Air' | 'Hydro' | 'Immersion' | string;
  imageUrl?: string;
  imageUrls?: string[];
}

export interface Staff {
  name: string;
  role: string;
  email: string;
  telegram: string;
  whatsapp: string;
  avatar: string;
  verified: boolean;
}

export interface HostingCabinet {
  id: string;
  name: string;
  capacity: string; // e.g. "10 ASIC Miners"
  cooling: string; // e.g. "Water Cooling / Dry Cooler"
  powerLimit: string; // e.g. "40 kW"
  pricePerMonth: number;
  setupFee: number;
  location: string;
  efficiency: string; // PUE
  description: string;
}

export const PRODUCTS: Product[] = [
  {
    id: "whatsminer-m66s-plus-plus",
    name: "WhatsMiner M66S++",
    brand: "MicroBT",
    model: "M66",
    price: 8150,
    hashrate: 356,
    hashrateUnit: "TH/s",
    power: 5518,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 15.5,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-12",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1733780648/2jlhmN_NuKdUgfx9y9laSeNaNho.png",
    description: "The WhatsMiner M66S++ is a high-performance SHA-256 miner from MicroBT. Operating at 5518W with an efficiency of 15.50 J/Unit, it generates a daily revenue of approximately $16.64 with a net daily profit of $3.40 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m6ds-plus",
    name: "WhatsMiner M6DS+",
    brand: "MicroBT",
    model: "M6D",
    price: 7200,
    hashrate: 540,
    hashrateUnit: "TH/s",
    power: 9200,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 17.04,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2026-03",
    noise: 75,
    coolingType: "Hydro",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1772964356/3jCDxGgbBE-1SyrDDDMR45ZJebk.png",
    description: "The WhatsMiner M6DS+ is a high-performance SHA-256 miner from MicroBT. Operating at 9200W with an efficiency of 17.04 J/Unit, it generates a daily revenue of approximately $25.24 with a net daily profit of $3.16 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m72s",
    name: "WhatsMiner M72S",
    brand: "MicroBT",
    model: "M72",
    price: 5600,
    hashrate: 264,
    hashrateUnit: "TH/s",
    power: 4000,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 15.15,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-12",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1765211230/Fnt-GOjmXbGJ3UwLAtPe1FovHIo.png",
    description: "The WhatsMiner M72S is a high-performance SHA-256 miner from MicroBT. Operating at 4000W with an efficiency of 15.15 J/Unit, it generates a daily revenue of approximately $12.34 with a net daily profit of $2.74 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m66s",
    name: "WhatsMiner M66S",
    brand: "MicroBT",
    model: "M66",
    price: 4999,
    hashrate: 298,
    hashrateUnit: "TH/s",
    power: 5513,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 18.5,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2023-11",
    noise: 50,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1701074731/xyshv8ytrr4dtcbjt3q9.png",
    description: "The WhatsMiner M66S is a high-performance SHA-256 miner from MicroBT. Operating at 5513W with an efficiency of 18.50 J/Unit, it generates a daily revenue of approximately $13.93 with a net daily profit of $0.70 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m63s",
    name: "WhatsMiner M63S",
    brand: "MicroBT",
    model: "M63",
    price: 4930,
    hashrate: 390,
    hashrateUnit: "TH/s",
    power: 7215,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 18.5,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2023-11",
    noise: 50,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1701074312/pd2ok7nxe0ywtfvfjmjw.png",
    description: "The WhatsMiner M63S is a high-performance SHA-256 miner from MicroBT. Operating at 7215W with an efficiency of 18.50 J/Unit, it generates a daily revenue of approximately $18.23 with a net daily profit of $0.91 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m76s-plus",
    name: "WhatsMiner M76S+",
    brand: "MicroBT",
    model: "M76",
    price: 4875,
    hashrate: 390,
    hashrateUnit: "TH/s",
    power: 5200,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 13.33,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-12",
    noise: 75,
    coolingType: "Immersion",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1733780648/2jlhmN_NuKdUgfx9y9laSeNaNho.png",
    description: "The WhatsMiner M76S+ is a high-performance SHA-256 miner from MicroBT. Operating at 5200W with an efficiency of 13.33 J/Unit, it generates a daily revenue of approximately $18.23 with a net daily profit of $5.75 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "sealminer-a3-air",
    name: "SealMiner A3 Air",
    brand: "Bitdeer",
    model: "A3",
    price: 3999,
    hashrate: 260,
    hashrateUnit: "TH/s",
    power: 3640,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 14,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-09",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1758232960/COgEF1eNuhWB0oV2417HW_Eg258.png",
    description: "The SealMiner A3 Air is a high-performance SHA-256 miner from Bitdeer. Operating at 3640W with an efficiency of 14.00 J/Unit, it generates a daily revenue of approximately $12.15 with a net daily profit of $3.42 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "a15xp-206t",
    name: "Avalon A15XP-206T",
    brand: "Canaan",
    model: "A15",
    price: 3979,
    hashrate: 206,
    hashrateUnit: "TH/s",
    power: 3667,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 17.8,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-12",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1731054564/yOzAH-Ks0FAS9ziLA2TpFME8fsY.png",
    description: "The Avalon A15XP-206T is a high-performance SHA-256 miner from Canaan. Operating at 3667W with an efficiency of 17.80 J/Unit, it generates a daily revenue of approximately $9.63 with a net daily profit of $0.83 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m70s",
    name: "WhatsMiner M70S",
    brand: "MicroBT",
    model: "M70",
    price: 2999,
    hashrate: 226,
    hashrateUnit: "TH/s",
    power: 3140,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 13.89,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-12",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1765129675/tS4hPI-QNj049sBOglADY8v7JtE.png",
    description: "The WhatsMiner M70S is a high-performance SHA-256 miner from MicroBT. Operating at 3140W with an efficiency of 13.89 J/Unit, it generates a daily revenue of approximately $10.56 with a net daily profit of $3.03 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "a15pro-218t",
    name: "Avalon A15Pro-218T",
    brand: "Canaan",
    model: "A15",
    price: 2499,
    hashrate: 218,
    hashrateUnit: "TH/s",
    power: 3662,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 16.8,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-02",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1743665309/EpYIT7gjMnmq26r9ts9eXCJjw88.png",
    description: "The Avalon A15Pro-218T is a high-performance SHA-256 miner from Canaan. Operating at 3662W with an efficiency of 16.80 J/Unit, it generates a daily revenue of approximately $10.19 with a net daily profit of $1.40 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "ofen-2-pro",
    name: "Ofen 2 Pro",
    brand: "21energy",
    model: "Ofen",
    price: 2240,
    hashrate: 60,
    hashrateUnit: "TH/s",
    power: 1100,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 18.33,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2026-04",
    noise: 35,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1773955273/PdaGTGDMosemTzRMwdsID2Gkg-A.png",
    description: "The Ofen 2 Pro is a high-performance SHA-256 miner from 21energy. Operating at 1100W with an efficiency of 18.33 J/Unit, it generates a daily revenue of approximately $2.80 with a net daily profit of $0.16 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m60s",
    name: "WhatsMiner M60S",
    brand: "MicroBT",
    model: "M60",
    price: 2105,
    hashrate: 186,
    hashrateUnit: "TH/s",
    power: 3441,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 18.5,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-02",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1698310158/r9oslhkzebwuxpswyeq0.png",
    description: "The WhatsMiner M60S is a high-performance SHA-256 miner from MicroBT. Operating at 3441W with an efficiency of 18.50 J/Unit, it generates a daily revenue of approximately $8.69 with a net daily profit of $0.44 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m60s-plus-plus",
    name: "WhatsMiner M60S++",
    brand: "Micro BT",
    model: "M60",
    price: 2100,
    hashrate: 226,
    hashrateUnit: "TH/s",
    power: 3600,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 15.93,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-12",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1733753630/gWwTZw9J2Uk_yX37GHoY061ixCo.png",
    description: "The WhatsMiner M60S++ is a high-performance SHA-256 miner from Micro BT. Operating at 3600W with an efficiency of 15.93 J/Unit, it generates a daily revenue of approximately $10.56 with a net daily profit of $1.92 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "a15pro-221t",
    name: "Avalon A15Pro-221T",
    brand: "Canaan",
    model: "A15",
    price: 1913,
    hashrate: 221,
    hashrateUnit: "TH/s",
    power: 3662,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 16.57,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-03",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1761674265/NiSzDhBJb09yCkQyLtthJ6zDzQ8.png",
    description: "The Avalon A15Pro-221T is a high-performance SHA-256 miner from Canaan. Operating at 3662W with an efficiency of 16.57 J/Unit, it generates a daily revenue of approximately $10.33 with a net daily profit of $1.54 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "antminer-s21e-hyd-288th",
    name: "Antminer S21e Hyd (288Th)",
    brand: "Bitmain",
    model: "S21",
    price: 1369.9,
    hashrate: 288,
    hashrateUnit: "TH/s",
    power: 4896,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 17,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-04",
    noise: 50,
    coolingType: "Hydro",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1744737700/k5V6JlKhyAlTa0ibQrR1WRoZ248.jpg",
    description: "The Antminer S21e Hyd (288Th) is a high-performance SHA-256 miner from Bitmain. Operating at 4896W with an efficiency of 17.00 J/Unit, it generates a daily revenue of approximately $13.46 with a net daily profit of $1.71 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m76s",
    name: "WhatsMiner M76S",
    brand: "MicroBT",
    model: "M76",
    price: 1332,
    hashrate: 362,
    hashrateUnit: "TH/s",
    power: 5200,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 14.36,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-12",
    noise: 75,
    coolingType: "Immersion",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1733780648/2jlhmN_NuKdUgfx9y9laSeNaNho.png",
    description: "The WhatsMiner M76S is a high-performance SHA-256 miner from MicroBT. Operating at 5200W with an efficiency of 14.36 J/Unit, it generates a daily revenue of approximately $16.92 with a net daily profit of $4.44 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "avalon-a1566",
    name: "Avalon A1566",
    brand: "Canaan",
    model: "A15",
    price: 1174,
    hashrate: 185,
    hashrateUnit: "TH/s",
    power: 3420,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 18.49,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-10",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1716505681/sbvjysji3pf3yw905t0i.jpg",
    description: "The Avalon A1566 is a high-performance SHA-256 miner from Canaan. Operating at 3420W with an efficiency of 18.49 J/Unit, it generates a daily revenue of approximately $8.65 with a net daily profit of $0.44 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m70splus",
    name: "WhatsMiner M70S+",
    brand: "MicroBT",
    model: "M70",
    price: 1161,
    hashrate: 244,
    hashrateUnit: "TH/s",
    power: 3140,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 12.87,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-12",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1765129675/tS4hPI-QNj049sBOglADY8v7JtE.png",
    description: "The WhatsMiner M70S+ is a high-performance SHA-256 miner from MicroBT. Operating at 3140W with an efficiency of 12.87 J/Unit, it generates a daily revenue of approximately $11.41 with a net daily profit of $3.87 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m76",
    name: "WhatsMiner M76",
    brand: "MicroBT",
    model: "M76",
    price: 968,
    hashrate: 336,
    hashrateUnit: "TH/s",
    power: 5200,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 15.48,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-12",
    noise: 75,
    coolingType: "Immersion",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1733780648/2jlhmN_NuKdUgfx9y9laSeNaNho.png",
    description: "The WhatsMiner M76 is a high-performance SHA-256 miner from MicroBT. Operating at 5200W with an efficiency of 15.48 J/Unit, it generates a daily revenue of approximately $15.71 with a net daily profit of $3.23 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m70",
    name: "WhatsMiner M70",
    brand: "MicroBT",
    model: "M70",
    price: 740,
    hashrate: 214,
    hashrateUnit: "TH/s",
    power: 3140,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 14.67,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2025-12",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1765129675/tS4hPI-QNj049sBOglADY8v7JtE.png",
    description: "The WhatsMiner M70 is a high-performance SHA-256 miner from MicroBT. Operating at 3140W with an efficiency of 14.67 J/Unit, it generates a daily revenue of approximately $10.00 with a net daily profit of $2.47 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m66s-plus",
    name: "WhatsMiner M66S+",
    brand: "MicroBT",
    model: "M66",
    price: 567,
    hashrate: 318,
    hashrateUnit: "TH/s",
    power: 5406,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 17,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-08",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1733754225/DiLj07ddmoO_zkuTm9UOknAOifM.png",
    description: "The WhatsMiner M66S+ is a high-performance SHA-256 miner from MicroBT. Operating at 5406W with an efficiency of 17.00 J/Unit, it generates a daily revenue of approximately $14.86 with a net daily profit of $1.89 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "whatsminer-m60s-plus",
    name: "WhatsMiner M60S+",
    brand: "Micro BT",
    model: "M60",
    price: 500,
    hashrate: 212,
    hashrateUnit: "TH/s",
    power: 3600,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 16.98,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-07",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1722354921/ysGSFzBuhAvzsUsDLBpdG1cAUtw.png",
    description: "The WhatsMiner M60S+ is a high-performance SHA-256 miner from Micro BT. Operating at 3600W with an efficiency of 16.98 J/Unit, it generates a daily revenue of approximately $9.91 with a net daily profit of $1.27 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "a15-194t",
    name: "Avalon A15-194T",
    brand: "Canaan",
    model: "A15",
    price: 500,
    hashrate: 194,
    hashrateUnit: "TH/s",
    power: 3647,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 18.8,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-12",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1731056143/2Gz0VVVjEza5EnkW9STwHGN50Bo.png",
    description: "The Avalon A15-194T is a high-performance SHA-256 miner from Canaan. Operating at 3647W with an efficiency of 18.80 J/Unit, it generates a daily revenue of approximately $9.07 with a net daily profit of $0.32 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "antminer-t21-180th",
    name: "Antminer T21 (180Th)",
    brand: "Bitmain",
    model: "T21",
    price: 500,
    hashrate: 180,
    hashrateUnit: "TH/s",
    power: 3420,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 19,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-04",
    noise: 75,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1754424982/X-XhJpGoG59k37IY_4Tru72y_RE.jpg",
    description: "The Antminer T21 (180Th) is a high-performance SHA-256 miner from Bitmain. Operating at 3420W with an efficiency of 19.00 J/Unit, it generates a daily revenue of approximately $8.41 with a net daily profit of $0.21 (estimated at $0.10/kWh electricity cost)."
  },
  {
    id: "avalon-a1566i",
    name: "Avalon A1566I",
    brand: "Canaan",
    model: "A15",
    price: 500,
    hashrate: 261,
    hashrateUnit: "TH/s",
    power: 4500,
    algorithm: "SHA-256",
    coins: ["BTC"],
    efficiency: 17.24,
    efficiencyUnit: "J/TH",
    status: "In Stock",
    releaseDate: "2024-07",
    noise: 50,
    coolingType: "Air",
    imageUrl: "https://res.cloudinary.com/dluwgr5op/image/upload/v1721344061/FHbdvgoyxjDvtRKzr0gqEqRSl60.jpg",
    description: "The Avalon A1566I is a high-performance SHA-256 miner from Canaan. Operating at 4500W with an efficiency of 17.24 J/Unit, it generates a daily revenue of approximately $12.20 with a net daily profit of $1.40 (estimated at $0.10/kWh electricity cost)."
  },
];

export const STAFF_MEMBERS: Staff[] = [
  {
    name: 'Alice Chen',
    role: 'Senior Sales Director',
    email: 'alice.c@apextomining.com',
    telegram: '@Alice_Apexto',
    whatsapp: '+86 138 2356 8890',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
    verified: true
  },
  {
    name: 'David Smith',
    role: 'Global Logistics Manager',
    email: 'david.smith@apextomining.com',
    telegram: '@David_Apexto_Logistics',
    whatsapp: '+1 (415) 890-4432',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150',
    verified: true
  },
  {
    name: 'Elena Petrova',
    role: 'Sales Representative (CIS Region)',
    email: 'elena.p@apextomining.com',
    telegram: '@Elena_Apexto',
    whatsapp: '+86 139 4432 9901',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150',
    verified: true
  },
  {
    name: 'Kenji Sato',
    role: 'Technical Support Lead',
    email: 'kenji.s@apextomining.com',
    telegram: '@Kenji_Apexto_Support',
    whatsapp: '+86 137 9900 1122',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150',
    verified: true
  }
];

export const SCAM_WARNINGS: { [key: string]: string } = {
  '@alice_apexto_support': 'This is an impersonation account. The official Telegram handle is @Alice_Apexto. They will never DM you first with investment schemes.',
  '@elena_apexto_sales': 'Impostor detected. The official handle is @Elena_Apexto. Always authenticate staff through our site.',
  '@apexto_miners_bot': 'Warning! This is a scam channel. Apexto Mining does not use automated bots to collect payments or deposits.',
  '@david_apexto_admin': 'Impostor alert. The official logistics coordinator Telegram is @David_Apexto_Logistics.'
};

export const HOSTING_CABINETS: HostingCabinet[] = [
  {
    id: 'hydro-cabinet-h12',
    name: 'Apexto Hydro Cooling Cabinet H12',
    capacity: '12 Hydro ASICs (e.g. S21 Hydro, M63S)',
    cooling: 'Water Loop & External Dry Cooler Support',
    powerLimit: '80 kW',
    pricePerMonth: 850,
    setupFee: 1200,
    location: 'Houston, Texas, USA',
    efficiency: '1.04 PUE',
    description: 'Industrial-grade water-cooling cabinet housing up to 12 heavy hydro miners. Features intelligent water flow controls, automatic leak detection, and heat recycling outlets.'
  },
  {
    id: 'immersion-tank-i8',
    name: 'Apexto Immersion Tank System I8',
    capacity: '8 Air-Cooled ASICs (Modified for Immersion)',
    cooling: 'Single-phase Dielectric Fluid Circulation',
    powerLimit: '35 kW',
    pricePerMonth: 600,
    setupFee: 950,
    location: 'Dubai, UAE',
    efficiency: '1.02 PUE',
    description: 'Advanced fluid-submersion system designed to operate air-cooled ASIC miners completely silently and at ultra-low chip temperatures, unlocking safe 15% overclocking margins.'
  }
];

export const BLOG_POSTS = [
  {
    id: 'btc-halving-2024-strategy',
    title: 'Post-Halving Survival Guide: Transitioning to Sub-20 J/T Hashing',
    summary: 'With BTC mining rewards halved, hardware efficiency is now a matter of survival. Learn why upgrading to S21 or M60S models makes financial sense.',
    date: '2026-05-15',
    readTime: '6 min read',
    category: 'Industry Insights'
  },
  {
    id: 'hydro-cooling-datacenter-upgrade',
    title: 'Why Hydro-Cooling is the Future of Enterprise Mining Farms',
    summary: 'Analyze the cooling efficiencies, reduction in noise complaints, and increased device lifespan of water-cooled containers versus traditional air setups.',
    date: '2026-05-28',
    readTime: '8 min read',
    category: 'Technical Guide'
  }
];
